from django.contrib import admin
from .models import UserInfo
from .forms import UserInfoForm

# Register your models here.

class UserInfoForm(admin.ModelAdmin):
    list_display = ["dept"] #list of things we wanna see in admin view
    form = UserInfoForm

admin.site.register(UserInfo , UserInfoForm)