from django.apps import AppConfig


class dashboardConfig(AppConfig):
    name = 'dashboard'
