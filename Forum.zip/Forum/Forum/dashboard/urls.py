from django.conf.urls import url
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
        url(r'^$' , views.index, name = 'index'),
        url(r'^formfill$' , views.formfill, name = 'formfill'),
        url(r'^upvote/(?P<obj_id>[0-9]+)/$', views.UpVote, name='upvote'),
        url(r'^downvote/(?P<obj_id>[0-9]+)/$', views.DownVote, name='downvote'),
    ]

#urlpatterns += static(settings.STATIC_URL, document_root = settings.STATIC_ROOT)
#urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
