from django.db import models
from datetime import datetime 

'''User Attributes--->
1)Home WiFi SSID, Password
2)Arduino Devices
3)Known people
4)Personal Details
'''

# Create your models here.

class UserInfo(models.Model):

    department_choices=(
        ('food' , 'Food'),
        ('health' , 'Health'),
        ('infra' , 'Infrastructure'),
        ('admin' , 'Administration'),
        ('acad' , 'Academics'),
        ('other' , 'Other'),
        )

    dept = models.CharField(max_length=20 , default="" , choices = department_choices , blank=False , null=False)
    message = models.CharField(max_length=500 , default = "" , blank = False , null = False)
    votes = models.IntegerField(default = 0 , blank = False , null = False) #can be blank for unsecured.
    date = models.DateTimeField(default=datetime.now, blank=True)
