from django.shortcuts import render , redirect
from django.utils.encoding import smart_str
from django.http import HttpResponse
from django.contrib.auth import authenticate , login , logout
#the form data->
from .forms import UserForm , UserInfoForm , LoginForm
from .models import UserInfo

# Create your views here.
def index(request):
    context = {'objs' : UserInfo.objects.all()[::-1]}
    return render(request , 'dashboard/index.html' , context)

def formfill(request):
    if request.method == "GET":
        form = UserInfoForm()
        context = {'title' : 'Fill in your message',
                   'form' : form,
                   'status' : 'fill'}
    else: #if method is POST type
        context = {'title' : 'Form has been saved successfully',
                   'form' : '',
                   'status' : 'filled'}
        form = UserInfoForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.username = request.user.username
            obj.save()
    return render(request , 'dashboard/formfill.html' , context)

def UpVote(request , obj_id):
    obj = UserInfo.objects.get(id = obj_id)
    obj.votes += 1
    obj.save()
    return redirect('/dashboard')

def DownVote(request , obj_id):
    obj = UserInfo.objects.get(id = obj_id)
    obj.votes -= 1
    obj.save()
    return redirect('/dashboard')
