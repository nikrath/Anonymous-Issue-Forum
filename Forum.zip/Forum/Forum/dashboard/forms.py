from django import forms
from django.contrib.auth.models import User
from .models import UserInfo

class UserInfoForm(forms.ModelForm):
    '''The User Information form containing home info'''
    class Meta:
        model = UserInfo
        fields = []
        for field in UserInfo._meta.get_fields(): #automatically update fields from userinfo model
            fields.append(field.name)
        exclude = ["date"]

    def __init__(self, *args, **kwargs):
        super(UserInfoForm, self).__init__(*args, **kwargs) # Call to ModelForm constructor
        self.fields['message'].widget.attrs['rows'] = 10
        self.fields['message'].widget.attrs['cols'] = 20
        

class UserForm(forms.ModelForm):
    '''The user login form'''
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = User 
        fields = ['username' , 'email' , 'first_name' , 'last_name' , 'password'] #used for registration of new candidates

class LoginForm(forms.Form):
    username = forms.CharField(required=True)
    password = forms.CharField(required=True , widget=forms.PasswordInput)
