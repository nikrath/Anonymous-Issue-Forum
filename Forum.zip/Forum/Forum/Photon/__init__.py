"""
Package for Photon.
"""
